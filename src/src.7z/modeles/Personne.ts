export class Personne {
  public pseudo: String;

  constructor(pseudo: String) {
    this.pseudo = pseudo;
  }
}
